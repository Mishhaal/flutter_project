## June 11, 2019

* Added dependency injection
* Refactored dio client
