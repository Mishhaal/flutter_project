package com.iotecksolutions.flutter_boilerplate_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
