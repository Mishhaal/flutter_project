class User {

}