class Strings {
  Strings._();

  //General
  static const String appName = "Boilerplate Project";
}
