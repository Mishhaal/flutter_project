class FontFamily {
  FontFamily._();

  static String productSans = "ProductSans";
  static String roboto = "Roboto";
}