mixin BaseSharedPreferenceHelper {
  Future<bool> clearSharedPreference();
}